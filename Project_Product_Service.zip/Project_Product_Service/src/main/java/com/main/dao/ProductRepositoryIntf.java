package com.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.main.model.Product;

public interface ProductRepositoryIntf extends JpaRepository<Product, Integer>{

}
