package com.main.service;

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.main.dao.ProductRepositoryIntf;
import com.main.model.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductServiceIntf {

	@Autowired
	ProductRepositoryIntf repo;

	public List<Product> viwAllProducts() {

		return repo.findAll();
	}

	public void saveProduct(Product product) {

		repo.save(product);
	}

	public Optional<Product> fetchProduct(int id) {

		return repo.findById(id);
	}

	/*
	 * @PostMapping("saveProduct") public void saveProduct(Product product) {
	 * repository.save(product); }
	 * 
	 * public List<Product> fetchData() {
	 * 
	 * return repository.findAll(); }
	 */

}
