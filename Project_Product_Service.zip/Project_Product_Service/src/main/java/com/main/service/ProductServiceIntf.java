package com.main.service;

import java.util.List;
import java.util.Optional;
import com.main.model.Product;

public interface ProductServiceIntf {

	List<Product> viwAllProducts();

	void saveProduct(Product product);

	Optional<Product> fetchProduct(int id);
	

	/*
	 * void saveProduct(Product product);
	 * 
	 * List<Product> fetchData();
	 * 
	 * List<Product> viwAllProducts();
	 */
	

}
