package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="orders")
public class Order {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String cust_name;
	private String address;
	private String status;
	private int product_id;
	private int quantity;

	public Order(int id, String cust_name, String address, String status, int product_id, int quantity) {
		super();
		this.id = id;
		this.cust_name = cust_name;
		this.address = address;
		this.status = status;
		this.product_id = product_id;
		this.quantity = quantity;
	}

	public Order() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String toString() {
		return "Order [id=" + id + ", cust_name=" + cust_name + ", address=" + address + ", status=" + status
				+ ", product_id=" + product_id + ", quantity=" + quantity + "]";
	}

}
