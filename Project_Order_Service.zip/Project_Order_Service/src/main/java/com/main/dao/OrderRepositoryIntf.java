package com.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.main.model.Order;


public interface OrderRepositoryIntf extends JpaRepository<Order, Integer> {
	

}
