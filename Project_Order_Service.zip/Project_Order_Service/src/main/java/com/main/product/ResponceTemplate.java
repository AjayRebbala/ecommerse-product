package com.main.product;

import com.main.model.Order;

public class ResponceTemplate {

	private Order order;
	private Product product;

	public ResponceTemplate() {
		super();
	}

	public ResponceTemplate(Order order, Product product) {
		super();
		this.order = order;
		this.product = product;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ResponceTemplate [order=" + order + ", product=" + product + "]";
	}

}
