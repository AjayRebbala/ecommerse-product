package com.main.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.main.model.Order;
import com.main.service.OrderServiceIntf;

@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	private OrderServiceIntf osf;
	
	@GetMapping("/getOrder")
	public ResponseEntity<List<Order>> vieAllOrders(){
		List<Order> list=osf.viwAllOrders();
		if(!list.isEmpty())
			return new ResponseEntity<>(list, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PostMapping("/saveOrder")
	public ResponseEntity<String> saveOrder(@RequestBody Order order) {
		osf.saveOrder(order);
		return new ResponseEntity<>("order Saved successfully",HttpStatus.OK );
	}
	/*
	 * @GetMapping("fetchOrder") public List<Order> fetchOrder(){
	 * 
	 * List<Order> list= osf.fetchOrder(); return list; }
	 */
	@GetMapping("/fetchOrder/{id}")
	public ResponseEntity<Optional<Order>> fetchOrder(@PathVariable("id") int id){
		
		Optional<Order> option=osf.fetchOrder(id);
		if(option.isPresent())
			return new ResponseEntity<>(option, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
}
