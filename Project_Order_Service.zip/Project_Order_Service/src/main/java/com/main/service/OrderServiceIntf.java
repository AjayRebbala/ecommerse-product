package com.main.service;

import java.util.List;
import java.util.Optional;

import com.main.model.Order;
import com.main.product.ResponceTemplate;

public interface OrderServiceIntf {

	void saveOrder(Order ord);

	/* List<Order> fetchOrder(); */

	/* ResponceTemplate getOrderWithProduct(int id); */

	Optional<Order> fetchOrder(int id);

	List<Order> viwAllOrders();
	

}
