package com.main.service;

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import com.main.dao.OrderRepositoryIntf;
import com.main.model.Order;

@Service
@Transactional
public class OrderServiceImpl implements OrderServiceIntf {

	@Autowired
	OrderRepositoryIntf repository;

	/*
	 * @Autowired private RestTemplate restTemplate;
	 */

	@PostMapping("saveOrder")
	public void saveOrder(Order ord) {
		repository.save(ord);
	}
	/*
	 * public List<Order> fetchOrder() {
	 * 
	 * return repository.findAll(); }
	 */

	
	public Optional<Order> fetchOrder(int id) {
	
		return repository.findById(id);
	}


	
	public List<Order> viwAllOrders() {
	
		return repository.findAll();
	}

	/*
	 * public ResponceTemplate getOrderWithProduct(int id) { ResponceTemplate rt =
	 * new ResponceTemplate(); Order order = repository.findById(id);
	 * System.out.println(); System.out.println(order); Product product =
	 * restTemplate.getForObject("http://localhost:8555/products/" +
	 * order.getProduct_id(), Product.class);
	 * 
	 * rt.setOrder(order); rt.setProduct(product); return rt; }
	 */
}
