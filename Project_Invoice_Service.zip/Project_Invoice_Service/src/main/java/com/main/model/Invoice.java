package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="tbl_invoice")
public class Invoice {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private double total;
	private String pay_status;
	private int order_id;
	public Invoice(int id, double total, String pay_status, int order_id) {
		super();
		this.id = id;
		this.total = total;
		this.pay_status = pay_status;
		this.order_id = order_id;
	}
	public Invoice() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getPay_status() {
		return pay_status;
	}
	public void setPay_status(String pay_status) {
		this.pay_status = pay_status;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	
	public String toString() {
		return "Invoice [id=" + id + ", total=" + total + ", pay_status=" + pay_status + ", order_id=" + order_id + "]";
	}

	
	

}
