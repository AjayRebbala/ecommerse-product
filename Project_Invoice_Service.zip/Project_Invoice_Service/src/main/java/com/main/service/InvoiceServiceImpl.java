package com.main.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import com.main.dao.InvoiceRepositoryIntf;
import com.main.model.Invoice;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceServiceIntf{

	@Autowired
	InvoiceRepositoryIntf repository;
	
	public void saveInvoice(Invoice invoice) {
		repository.save(invoice);
		
	}

	
	public List<Invoice> viewAllInvoices() {
		
		return repository.findAll();
	}


	
	public Optional<Invoice> fetchInvoice(int id) {
		
		return repository.findById(id);
	}

}
